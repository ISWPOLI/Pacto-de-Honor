
public class Acciones {

	public static String enunciadoUno(){
		return "1. Seleccionar personaje al principio del juego, despu�s de Logearse";
	}
	public static String enunciadoDos(){
		return "2. Seleccionar personaje para regalarselo a otro jugador";
	}
	public static String enunciadoTres(){
		return "3. Seleccionar personaje, Recibir personaje regalado por otro jugador";
	}
	public static String enunciadoCuatro(){
		return "4. Seleccionar personaje, desbloqueo de personaje en el transurso del"
				+ " juego.";
	}
	public static String enunciadoCinco(){
		return "5. Seleccionar personaje, comprar personaje";
	}
	public static String enunciadoSeis(){
		return "6. Logro MiKuplagio, acumular dos horas de juego.";
	}
	public static String enunciadoSiete(){
		return "7. Logro My Life Plagio, Permanecer durante 2 d�as en las primeras "
				+ "5 posiciones de las tablas de ranking.";
	}
	public static String enunciadoOcho(){
		return "8. Logro Mi SkillPlagio, debe ganar una batalla en cada escenario.";
	}
	public static String enunciadoNueve(){
		return "9. Logro The originalPlagio, acumular 3 batallas victoriosas";
	}
	public static String enunciadoDiez(){
		return "10. Logro Mi HitBackground, ganar las primeras 4 batallas de cada"
				+ "mundo en menos de 5 minutos.";
	}
	public static String enunciadoOnce(){
		return "11. Logro Trendy, realizar m�s de 10 interaciones con amigos y c�digos"
				+ " recibidos";
	}
	public static String enunciadoDoce(){
		return "12. Logo The Richest, logro dado por obtener monedas en el juego.";
	}
	public static String enunciadoTrece(){
		return "13. Logro The Unlocker, logro obtenido por desbloquear personajes";
	}
	public static String enunciadoCatorce(){
		return "14. Logro 5 in a row, pasar todo un mundo sin perder ni una sola vez.";
	}
	public static String enunciadoQuince(){
		return "15. Ranking diario, tener una ubicaci�n importante en el Ranking";
	}
	public static String enunciadoDieciseis(){
		return "16. Ranking semanal, tener una ubicaci�n importante en el Ranking";
	}
	public static String enunciadoDiecisiete (){
		return "17. Ranking poli, tener una ubicaci�n importante en el Ranking";
	}
	public static String enunciadoDieciOcho(){
		return "18. Ranking general, tener una ubicaci�n importante en el Ranking";
	}
	public static String enunciadoDiecinueve (){
		return "19. Mundo, entrar a un mundo";
	}
	public static String enunciadoVeinte(){
		return "20. Nivel, entrar a un nivel";
	}
	public static String enunciadoVeintiuno(){
		return "21. Invitar amigos, invitar amigos al juego";
	}
	public static String enunciadoVeintidos(){
		return "22. M�sica, quitar m�sica en el juego o ponerla";
	}
}

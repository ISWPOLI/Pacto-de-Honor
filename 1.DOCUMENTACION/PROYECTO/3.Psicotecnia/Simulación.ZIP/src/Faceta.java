
public class Faceta {

	public static String facetaUno() {//7
		if (Main.a1.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaDos() {//27
		if (Main.a2.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaTres(){//29
		if(Main.a3.equals("false"))return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaCuatro() {//81
		if (Main.a4.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaCinco() {//84
		if (Main.a5.equals("false"))
			return "RS";
		return "PAS";
	}
	public static String facetaSeis() {//100
		if (Main.a6.equals("true"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaSiete() {//103
		if (Main.a7.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaOcho() {//104
		if (Main.a8.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaNueve() {//105
		if (Main.a9.equals("false"))
			return "RS";
		return "PAS";
	}
	public static String facetaDiez() {//123
		if (Main.a10.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaOnce() {//199
		if (Main.a11.equals("true"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaDoce() {//202
		if (Main.a12.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaTrece() {//235
		if (Main.a13.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
	public static String facetaCatorce() {//266
		if (Main.a14.equals("false"))
			return "PAS";
		return "RS";
	}
	public static String facetaQuince() {//269
		if (Main.a15.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaDieciseis() {//283
		if (Main.a16.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaDiecisiete() {//284
		if (Main.a17.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaDieciocho() {//374
		if (Main.a18.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaDiecinueve() {//412
		if (Main.a19.equals("false"))
			return "RS";
		return "PAS";
	}
	public static String facetaVeinte() {//418
		if (Main.a20.equals("false"))
			return "RS";
		return "PAS";
	}
	public static String facetaVeintiUno() {//419
		if (Main.a21.equals("true"))
			return "PAS";
		return "No tiene otra faceta";
	}
	public static String facetaVeintidos() {//431
		if (Main.a22.equals("false"))
			return "RS";
		return "No tiene otra faceta";
	}
}

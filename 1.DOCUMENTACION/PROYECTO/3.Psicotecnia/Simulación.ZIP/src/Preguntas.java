
public class Preguntas {
	
	public static String preguntaSiete (String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoSiete (){
		return "7. Me gustan leer los art�culos sobre cr�menes en los periodicos";
	}
	public static String preguntaVeintisiete(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoVeintisiete (){
		return "27. Por principio, cuando alguien me hace alg�n mal siento que, de ser posible"
				+ " deberia pagarle con la misma moneda";
	}
	public static String preguntaVeintinueve(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoVeintinueve (){
		return "29. En ocasiones siento deseos de maldecir";
	}
	public static String preguntaOchentaUno(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoOchentaUno (){
		return "81. Creo que la mayoria de la gente mentir�a para salir adelante";
	}
	public static String preguntaOchentaCuatro(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "false";
	}
	public static String enunciadoOchentaCuatro (){
		return "84. Cuando joven me suspendieron de la escuela una o m�s veces "
				+ "por mala conducta";
	}
	public static String preguntaCien(String faceta){
		if(faceta.equals("RS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCien (){
		return "100. Nunca he hecho algo peligroso s�lo por el gusto de hacerlo";
	}
	public static String preguntaCientoTres(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCientoTres (){
		return "103. Disfruto m�s de una carrera o de un juego cuando apuesto.";
	}
	public static String preguntaCientoCuatro(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCientoCuatro(){
		return "104. La mayor parte de la gente es honrada principalmente por temor a ser"
				+ " descubierta";
	}
	public static String preguntaCientoCinco(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "false";
	}
	public static String enunciadoCientoCinco(){
		return "105. En la escuela algunas veces me llevaron ante el director "
				+ "por mala conducta";
	}
	public static String preguntaCientoVeintiTres(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCientoVeintiTres (){
		return "123. Si pudiera entrar a un cine sin pagar y estuviera "
				+ "seguro de no ser descubierto, probablemente lo har�a.";
	}
	public static String preguntaCientoNoventaNueve(String faceta){
		if(faceta.equals("RS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCientoNoventaNueve (){
		return "199. Me gusta la ciencia.";
	}
	public static String preguntaDocientosDos(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoDocientosDos(){
		return "202. A menudo mis padres se opon�an a la clase de gente que frecuentaba";
	}
	public static String preguntaDocientosTreintaCinco(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoDocientosTreintaCinco(){
		return "235. Fui una persona lenta para aprender en la escuela";
	}
	public static String preguntaDocientosSesentaSeis(String faceta){
		if(faceta.equals("PAS"))return "false";
		return "true";
	}
	public static String enunciadoDocientosSesentaSeis(){
		return "266. Nunca he tenido problemas con la ley.";
	}
	public static String preguntaDocientosSesentaNueve(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoDocientosSesentaNueve(){
		return "269. Si varias personas se hallan en apuros, lo mejor que pueden "
				+ "hacer es ponerse de acuerdo sobre lo que van a decir y mantenerse "
				+ "firmes en lo que acuerden.";
	}
	public static String preguntaDocientosOchentaTres(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoDocientosOchentaTres(){
		return "283. La persona que causa tentaci�n dejando propiedades de valor sin "
				+ "protecci�n, es tan culpable del robo como el ladr�n";
	}
	public static String preguntaDocientosOchentaCuatro(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoDocientosOchentaCuatro(){
		return "284. Creo que casi todo el mundo mentir�a para evitarse problemas";
	}
	public static String preguntaTrecientosSetentaCuatro(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoTrecientosSetentaCuatro(){
		return "374. La mayor�a de las personas utilizar�a medios, de alguna manera "
				+ "discutibles, para mejorar su situaci�n en la vida.";
	}
	public static String preguntaCuatrocientosDoce(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "false";
	}
	public static String enunciadoCuatrocientosDoce (){
		return "412. Cuando era chico(a) frecuentemente no iba a la escuela aunque "
				+ "debia haberlo hecho";
	}
	public static String preguntaCuatrocientosDieciocho(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "false";
	}
	public static String enunciadoCuatrocientosDieciocho(){
		return "418. Es correcto tratar de evitar el cumplimiento de la ley,"
				+ " siempre que �sta no se viole";
	}
	public static String preguntaCuatrocientosDiecinueve(String faceta){
		if(faceta.equals("PAS"))return "true";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCuatrocientosDiecinueve(){
		return "419. Hay ciertas personas que me desagradan tanto, que me alegro "
				+ "interiormente cuando est�n pagando las consecuencias por algo que "
				+ "han hecho";
	}
	public static String preguntaCuatrocientosTreintaUno(String faceta){
		if(faceta.equals("RS"))return "false";
		return "No pertenece a ninguna faceta";
	}
	public static String enunciadoCuatrocientosTreintaUno(){
		return "431. En la escuela mis calificaciones en conducta generalmente eran malas";
	}
}

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
	
	public static String a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21, a22;
	public static int PAS;

	public static void main(String[] args) throws Exception{
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println(Acciones.enunciadoUno());
		a1=in.readLine();
		if(Preguntas.preguntaSiete(Faceta.facetaUno()).equals(Main.a1))PAS +=1;
		System.out.println(Acciones.enunciadoDos());
		a2=in.readLine();
		if(Preguntas.preguntaVeintisiete(Faceta.facetaDos()).equals(Main.a2))PAS+=1;
		System.out.println(Acciones.enunciadoTres());
		a3=in.readLine();
		if(Preguntas.preguntaVeintinueve(Faceta.facetaTres()).equals(Main.a3))PAS+=1;
		System.out.println(Acciones.enunciadoCuatro());
		a4=in.readLine();
		System.out.println(Acciones.enunciadoCinco());
		a5=in.readLine();
		if(Preguntas.preguntaOchentaCuatro(Faceta.facetaCinco()).equals(Main.a5))PAS+=1;
		System.out.println(Acciones.enunciadoSeis());
		a6=in.readLine();
		if(Preguntas.preguntaCien(Faceta.facetaSeis()).equals(Main.a6))PAS+=1;
		System.out.println(Acciones.enunciadoSiete());
		a7=in.readLine();
		if(Preguntas.preguntaCientoTres(Faceta.facetaSiete()).equals(Main.a7))PAS+=1;
		System.out.println(Acciones.enunciadoOcho());
		a8=in.readLine();
		System.out.println(Acciones.enunciadoNueve());
		a9=in.readLine();
		if(Preguntas.preguntaCientoCinco(Faceta.facetaNueve()).equals(Main.a9))PAS+=1;
		System.out.println(Acciones.enunciadoDiez());
		a10=in.readLine();
		System.out.println(Acciones.enunciadoOnce());
		a11=in.readLine();
		if(Preguntas.preguntaCientoNoventaNueve(Faceta.facetaOnce()).equals(Main.a11))PAS+=1;
		System.out.println(Acciones.enunciadoDoce());
		a12=in.readLine();
		if(Preguntas.preguntaDocientosDos(Faceta.facetaDoce()).equals(Main.a12))PAS+=1;
		System.out.println(Acciones.enunciadoTrece());
		a13=in.readLine();
		if(Preguntas.preguntaDocientosTreintaCinco(Faceta.facetaTrece()).equals(Main.a13))PAS+=1;
		System.out.println(Acciones.enunciadoCatorce());
		a14=in.readLine();
		if(Preguntas.preguntaDocientosSesentaSeis(Faceta.facetaCatorce()).equals(Main.a14))PAS+=1;
		System.out.println(Acciones.enunciadoQuince());
		a15=in.readLine();
		System.out.println(Acciones.enunciadoDieciseis());
		a16=in.readLine();
		System.out.println(Acciones.enunciadoDiecisiete());
		a17=in.readLine();
		System.out.println(Acciones.enunciadoDieciOcho());
		a18=in.readLine();
		System.out.println(Acciones.enunciadoDiecinueve());
		a19=in.readLine();
		if(Preguntas.preguntaCuatrocientosDoce(Faceta.facetaDiecinueve()).equals(Main.a19))PAS+=1;
		System.out.println(Acciones.enunciadoVeinte());
		a20=in.readLine();
		if(Preguntas.preguntaCuatrocientosDieciocho(Faceta.facetaVeinte()).equals(Main.a20))PAS+=1;
		System.out.println(Acciones.enunciadoVeintiuno());
		a21=in.readLine();
		System.out.println(Acciones.enunciadoVeintidos());
		a22=in.readLine();
		if(Preguntas.preguntaCuatrocientosTreintaUno(Faceta.facetaVeintidos()).equals(Main.a22))PAS+=1;
		System.out.println("Puntos Faceta PAS "+PAS);

	}


}
